import java.io.IOException;
import java.io.File;

import de.hamster.debugger.model.Territorium;import de.hamster.debugger.model.Territory;import de.hamster.model.HamsterException;import de.hamster.model.HamsterInitialisierungsException;import de.hamster.model.HamsterNichtInitialisiertException;import de.hamster.model.KachelLeerException;import de.hamster.model.MauerDaException;import de.hamster.model.MaulLeerException;import de.hamster.model.MouthEmptyException;import de.hamster.model.WallInFrontException;import de.hamster.model.TileEmptyException;import de.hamster.debugger.model.Hamster;public class HamsterRenderer implements de.hamster.model.HamsterProgram {public void main() {
	HamV2 ham = new HamV2();
	ham.init(1,1,1,9999);
	
	//File currentDir = new File("Test.txt");
	//ham.schreib("" + currentDir.getAbsoluteFile());
	
	int[][][] Datei = null;
	//DateiIO leser = new DateiIO();
	//int[][][] Datei = leser.main(String[]);
	
	try{
	Datei = DateiIO.main("");
	}catch(IOException e){
	System.out.println("Error");
	}
	for(int i = 0;i<Datei.length;i++){
	int[][] L = Datei[i];
	//ham.gib(L[ham.getX()][ham.getY()] * 9);
	//ham.schreib("" + L[3][0]);
	//ham.schreib("" + L[0][3]);
	while(true){
		while(ham.vornFrei()){
			ham.gib(L[ham.getX()][ham.getY()] * 12);
			ham.vor();
		}
		ham.gib(L[ham.getX()][ham.getY()] * 12);
		ham.dreheUm(2);
		ham.vor(-1);
		ham.dreheUm(1);
		if(ham.vornFrei()){
			ham.vor();
			ham.dreheUm(1);
		}else{
			break;
		}
	}	
	ham.dreheUm(2);
	ham.vor(-1);
	ham.dreheUm(-1);
	ham.schreib("N�chste Szene");
	while(true){
		while(ham.vornFrei()){
			ham.nimm(-1);
			ham.vor();
		}
		ham.nimm(-1);
		ham.dreheUm(2);
		ham.vor(-1);
		ham.dreheUm(1);
		if(ham.vornFrei()){
			ham.vor();
			ham.dreheUm(1);
		}else{
			break;
		}
	}
	ham.dreheUm(2);
	ham.vor(-1);
	ham.dreheUm(-1);
	}			
} 
  
}
import de.hamster.debugger.model.Territorium;import de.hamster.debugger.model.Territory;import de.hamster.model.HamsterException;import de.hamster.model.HamsterInitialisierungsException;import de.hamster.model.HamsterNichtInitialisiertException;import de.hamster.model.KachelLeerException;import de.hamster.model.MauerDaException;import de.hamster.model.MaulLeerException;import de.hamster.model.MouthEmptyException;import de.hamster.model.WallInFrontException;import de.hamster.model.TileEmptyException;import de.hamster.debugger.model.Hamster;public class TestHamster implements de.hamster.model.HamsterProgram {public void main() {
    HamV2 ham = new HamV2();
    ham.init(5,5,0,10);
    ham.vor(3);
    ham.dreheUm(1);
    ham.gib(-1);
    ham.nimm(-1);
    ham.schreib("" + LeanderMockup.getDatei());
}
}